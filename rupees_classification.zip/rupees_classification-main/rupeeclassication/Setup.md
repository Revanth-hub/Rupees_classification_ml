
```
sudo apt-get update --allow-releaseinfo-change

```

Install opencv from here

https://raspberrypi-guide.github.io/programming/install-opencv.html

https://raspberrypi-guide.github.io/electronics/using-usb-webcams

Install tensorflow_runtime

https://www.tensorflow.org/lite/guide/python

